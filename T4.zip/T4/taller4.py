import numpy as np
import matplotlib.pyplot as plt
from scipy.stats import poisson, norm, expon, binom
import math

def pregunta_3_4_poisson():
    """Preguntas 3 y 4: Distribución Poisson P(X=3) con M=4"""
    print("=== PREGUNTAS 3 y 4: DISTRIBUCIÓN POISSON ===")
    print("X ~ Poisson(M=4), calcular P(X=3)")
    
    M = 4
    x = 3
    
    # Usando scipy
    prob_scipy = poisson.pmf(x, M)
    
    # Cálculo manual usando la fórmula
    prob_manual = (math.exp(-M) * (M ** x)) / math.factorial(x)
    
    print(f"Parámetros: M = {M}, x = {x}")
    print(f"Fórmula: P(X={x}) = (e^(-{M}) * {M}^{x}) / {x}!")
    print(f"Resultado scipy: {prob_scipy:.6f}")
    print(f"Resultado manual: {prob_manual:.6f}")
    print(f"Porcentaje: {prob_scipy * 100:.2f}%")
    
    return prob_scipy

def pregunta_5_6_poisson():
    """Preguntas 5 y 6: Distribución Poisson P(X=5) con M=4"""
    print("\n=== PREGUNTAS 5 y 6: DISTRIBUCIÓN POISSON ===")
    print("X ~ Poisson(M=4), calcular P(X=5)")
    
    M = 4
    x = 5
    
    # Usando scipy
    prob_scipy = poisson.pmf(x, M)
    
    # Cálculo manual usando la fórmula
    prob_manual = (math.exp(-M) * (M ** x)) / math.factorial(x)
    
    print(f"Parámetros: M = {M}, x = {x}")
    print(f"Fórmula: P(X={x}) = (e^(-{M}) * {M}^{x}) / {x}!")
    print(f"Resultado scipy: {prob_scipy:.6f}")
    print(f"Resultado manual: {prob_manual:.6f}")
    print(f"Porcentaje: {prob_scipy * 100:.2f}%")
    
    return prob_scipy

def pregunta_7_comparacion():
    """Pregunta 7: Comparación de probabilidades"""
    print("\n=== PREGUNTA 7: COMPARACIÓN ===")
    
    prob_3 = poisson.pmf(3, 4)
    prob_5 = poisson.pmf(5, 4)
    
    print(f"P(X=3) = {prob_3:.4f} = {prob_3 * 100:.2f}%")
    print(f"P(X=5) = {prob_5:.4f} = {prob_5 * 100:.2f}%")
    
    # Según el PDF menciona 19.54% y 15.63%
    print("\nComparación con valores del PDF:")
    print(f"Nuestro P(X=3): {prob_3 * 100:.2f}% vs PDF: 19.54%")
    print(f"Nuestro P(X=5): {prob_5 * 100:.2f}% vs PDF: 15.63%")
    
    diferencia_3 = abs(prob_3 * 100 - 19.54)
    diferencia_5 = abs(prob_5 * 100 - 15.63)
    
    print(f"Diferencia para P(X=3): {diferencia_3:.2f}%")
    print(f"Diferencia para P(X=5): {diferencia_5:.2f}%")

def problema_normal():
    """Problema de distribución normal - peso de baterías"""
    print("\n=== PROBLEMA DISTRIBUCIÓN NORMAL ===")
    print("Peso de baterías ~ N(μ=6, σ=2), P(X > 8)")
    
    mu = 6  # media
    sigma = 2  # desviación estándar
    x_valor = 8  # valor para calcular P(X > 8)
    
    print(f"Parámetros: μ = {mu}, σ = {sigma}")
    print(f"Calcular: P(X > {x_valor})")
    
    # Calcular Z-score
    z_score = (x_valor - mu) / sigma
    print(f"Z-score: Z = ({x_valor} - {mu}) / {sigma} = {z_score}")
    
    # Calcular probabilidad usando scipy
    prob = 1 - norm.cdf(x_valor, mu, sigma)
    prob_z = 1 - norm.cdf(z_score)
    
    print(f"\nResultados:")
    print(f"P(X > {x_valor}) = 1 - P(X ≤ {x_valor})")
    print(f"Usando scipy directo: {prob:.6f}")
    print(f"Usando Z-score: {prob_z:.6f}")
    print(f"Porcentaje: {prob * 100:.2f}%")
    
    # Verificar con valores de la tabla normal
    print(f"\nVerificación con valores del PDF:")
    print(f"Nuestro resultado: {prob * 100:.2f}%")
    print(f"Valor en PDF: 15.87%")
    
    return prob, z_score

def problema_exponencial_1():
    """Caso 1: Distribución Exponencial - Tiempo entre llegadas"""
    print("\n=== CASO 1: DISTRIBUCIÓN EXPONENCIAL ===")
    print("Tiempo entre llegadas ~ Exp(λ=4 clientes/hora), P(T < 10 min)")
    
    lambda_hora = 4  # clientes por hora
    lambda_min = lambda_hora / 60  # convertir a minutos
    t = 10  # minutos
    
    print(f"Parámetros:")
    print(f"λ = {lambda_hora} clientes/hora = {lambda_min:.4f} clientes/minuto")
    print(f"t = {t} minutos")
    
    # Calcular probabilidad usando CDF
    prob = expon.cdf(t, scale=1/lambda_min)
    
    # Cálculo manual
    prob_manual = 1 - math.exp(-lambda_min * t)
    
    print(f"\nFórmula: P(T ≤ {t}) = 1 - e^(-λt)")
    print(f"Cálculo: 1 - e^(-{lambda_min:.4f} × {t})")
    print(f"Resultado scipy: {prob:.6f}")
    print(f"Resultado manual: {prob_manual:.6f}")
    print(f"Porcentaje: {prob * 100:.2f}%")
    
    return prob, lambda_min

def problema_exponencial_2():
    """Caso 2: Distribución Exponencial - Vida útil de componentes"""
    print("\n=== CASO 2: DISTRIBUCIÓN EXPONENCIAL ===")
    print("Vida útil ~ Exp(λ=1/1000), P(T > 1500 horas)")
    
    vida_media = 1000  # horas
    lambda_val = 1 / vida_media
    t = 1500  # horas
    
    print(f"Parámetros:")
    print(f"Vida media = {vida_media} horas")
    print(f"λ = 1/{vida_media} = {lambda_val:.6f}")
    print(f"t = {t} horas")
    
    # Calcular probabilidad usando función de supervivencia
    prob = expon.sf(t, scale=1/lambda_val)
    
    # Cálculo manual
    prob_manual = math.exp(-lambda_val * t)
    
    print(f"\nFórmula: P(T > {t}) = e^(-λt)")
    print(f"Cálculo: e^(-{lambda_val:.6f} × {t})")
    print(f"Resultado scipy: {prob:.6f}")
    print(f"Resultado manual: {prob_manual:.6f}")
    print(f"Porcentaje: {prob * 100:.2f}%")
    
    return prob, lambda_val

def problema_binomial_1():
    """Caso 1: Distribución Binomial - Examen de opción múltiple"""
    print("\n=== CASO 1: DISTRIBUCIÓN BINOMIAL ===")
    print("10 preguntas, 4 opciones cada una, P(X = 6 aciertos)")
    
    n = 10  # número de preguntas
    p = 0.25  # probabilidad de acierto por pregunta
    k = 6  # número de aciertos deseado
    
    print(f"Parámetros:")
    print(f"n = {n}, p = {p}, k = {k}")
    print(f"q = 1 - p = {1-p}")
    
    # Calcular probabilidad
    prob = binom.pmf(k, n, p)
    
    # Cálculo manual
    combinaciones = math.comb(n, k)
    prob_manual = combinaciones * (p ** k) * ((1-p) ** (n-k))
    
    print(f"\nFórmula: P(X = {k}) = C({n},{k}) × p^{k} × q^{n-k}")
    print(f"Cálculo: {combinaciones} × {p}^{k} × {1-p}^{n-k}")
    print(f"Resultado scipy: {prob:.6f}")
    print(f"Resultado manual: {prob_manual:.6f}")
    print(f"Porcentaje: {prob * 100:.2f}%")
    
    return prob, combinaciones

def problema_binomial_2():
    """Caso 2: Distribución Binomial - Control de calidad"""
    print("\n=== CASO 2: DISTRIBUCIÓN BINOMIAL ===")
    print("20 artículos, 5% defectuosos, P(X ≥ 2 defectuosos)")
    
    n = 20  # tamaño de muestra
    p = 0.05  # probabilidad de defecto
    k_min = 2  # mínimo número de defectuosos
    
    print(f"Parámetros:")
    print(f"n = {n}, p = {p}")
    print(f"Calcular: P(X ≥ {k_min})")
    
    # Calcular usando complemento
    prob_complemento = binom.cdf(k_min - 1, n, p)
    prob = 1 - prob_complemento
    
    # Calcular manualmente
    prob_0 = binom.pmf(0, n, p)
    prob_1 = binom.pmf(1, n, p)
    prob_manual = 1 - prob_0 - prob_1
    
    print(f"\nEstrategia: P(X ≥ {k_min}) = 1 - P(X ≤ {k_min-1})")
    print(f"P(X ≥ {k_min}) = 1 - [P(X=0) + P(X=1)]")
    print(f"Cálculo: 1 - [{prob_0:.6f} + {prob_1:.6f}]")
    print(f"Resultado scipy: {prob:.6f}")
    print(f"Resultado manual: {prob_manual:.6f}")
    print(f"Porcentaje: {prob * 100:.2f}%")
    
    # Mostrar probabilidades individuales
    print(f"\nProbabilidades individuales:")
    print(f"P(X=0) = {prob_0:.6f}")
    print(f"P(X=1) = {prob_1:.6f}")
    
    return prob, prob_0, prob_1

def graficar_poisson():
    """Graficar distribución de Poisson"""
    print("\n=== GRÁFICA DISTRIBUCIÓN POISSON ===")
    
    M = 4
    x_vals = np.arange(0, 11)
    probs = poisson.pmf(x_vals, M)
    
    plt.figure(figsize=(15, 10))
    
    plt.subplot(2, 3, 1)
    plt.bar(x_vals, probs, color='skyblue', alpha=0.7)
    plt.axvline(x=3, color='red', linestyle='--', alpha=0.7, label='P(X=3)')
    plt.axvline(x=5, color='green', linestyle='--', alpha=0.7, label='P(X=5)')
    plt.xlabel('Número de clientes (x)')
    plt.ylabel('Probabilidad P(X=x)')
    plt.title(f'Distribución Poisson (M={M})')
    plt.legend()
    plt.grid(True, alpha=0.3)
    
    # Destacar las probabilidades calculadas
    plt.text(3, poisson.pmf(3, M) + 0.01, f'P(X=3)={poisson.pmf(3, M):.3f}', 
             ha='center', color='red')
    plt.text(5, poisson.pmf(5, M) + 0.01, f'P(X=5)={poisson.pmf(5, M):.3f}', 
             ha='center', color='green')
    
    return x_vals, probs

def graficar_normal():
    """Graficar distribución normal"""
    print("\n=== GRÁFICA DISTRIBUCIÓN NORMAL ===")
    
    mu = 6
    sigma = 2
    x_critico = 8
    
    x_vals = np.linspace(mu - 4*sigma, mu + 4*sigma, 1000)
    y_vals = norm.pdf(x_vals, mu, sigma)
    
    plt.subplot(2, 3, 2)
    plt.plot(x_vals, y_vals, 'b-', linewidth=2, label=f'N({mu},{sigma}²)')
    
    # Sombrear área P(X > 8)
    x_fill = np.linspace(x_critico, mu + 4*sigma, 100)
    y_fill = norm.pdf(x_fill, mu, sigma)
    plt.fill_between(x_fill, y_fill, color='red', alpha=0.3, label=f'P(X > {x_critico})')
    
    plt.axvline(x=mu, color='black', linestyle='--', alpha=0.5, label=f'μ = {mu}')
    plt.axvline(x=x_critico, color='red', linestyle='--', alpha=0.7, label=f'x = {x_critico}')
    
    plt.xlabel('Peso de baterías')
    plt.ylabel('Densidad de probabilidad')
    plt.title('Distribución Normal - Peso de Baterías')
    plt.legend()
    plt.grid(True, alpha=0.3)

def graficar_exponencial_1():
    """Graficar caso 1 de distribución exponencial"""
    print("\n=== GRÁFICA DISTRIBUCIÓN EXPONENCIAL CASO 1 ===")
    
    lambda_min = 4/60  # clientes por minuto
    t_critico = 10  # minutos
    
    t_vals = np.linspace(0, 60, 1000)
    pdf_vals = expon.pdf(t_vals, scale=1/lambda_min)
    
    plt.subplot(2, 3, 3)
    plt.plot(t_vals, pdf_vals, 'g-', linewidth=2, label=f'Exp(λ={lambda_min:.4f})')
    
    # Sombrear área P(T ≤ 10)
    t_fill = np.linspace(0, t_critico, 100)
    pdf_fill = expon.pdf(t_fill, scale=1/lambda_min)
    plt.fill_between(t_fill, pdf_fill, color='orange', alpha=0.3, label=f'P(T ≤ {t_critico})')
    
    plt.axvline(x=t_critico, color='red', linestyle='--', alpha=0.7, label=f't = {t_critico} min')
    
    plt.xlabel('Tiempo entre llegadas (minutos)')
    plt.ylabel('Densidad de probabilidad')
    plt.title('Distribución Exponencial - Tiempo entre Llegadas')
    plt.legend()
    plt.grid(True, alpha=0.3)

def graficar_exponencial_2():
    """Graficar caso 2 de distribución exponencial"""
    print("\n=== GRÁFICA DISTRIBUCIÓN EXPONENCIAL CASO 2 ===")
    
    lambda_val = 1/1000
    t_critico = 1500  # horas
    
    t_vals = np.linspace(0, 3000, 1000)
    pdf_vals = expon.pdf(t_vals, scale=1/lambda_val)
    
    plt.subplot(2, 3, 4)
    plt.plot(t_vals, pdf_vals, 'purple', linewidth=2, label=f'Exp(λ={lambda_val:.6f})')
    
    # Sombrear área P(T > 1500)
    t_fill = np.linspace(t_critico, 3000, 100)
    pdf_fill = expon.pdf(t_fill, scale=1/lambda_val)
    plt.fill_between(t_fill, pdf_fill, color='pink', alpha=0.3, label=f'P(T > {t_critico})')
    
    plt.axvline(x=t_critico, color='red', linestyle='--', alpha=0.7, label=f't = {t_critico} horas')
    plt.axvline(x=1000, color='black', linestyle='--', alpha=0.5, label='Vida media = 1000')
    
    plt.xlabel('Tiempo de vida (horas)')
    plt.ylabel('Densidad de probabilidad')
    plt.title('Distribución Exponencial - Vida Útil')
    plt.legend()
    plt.grid(True, alpha=0.3)

def graficar_binomial_1():
    """Graficar caso 1 de distribución binomial"""
    print("\n=== GRÁFICA DISTRIBUCIÓN BINOMIAL CASO 1 ===")
    
    n = 10
    p = 0.25
    k_destacado = 6
    
    x_vals = np.arange(0, n+1)
    probs = binom.pmf(x_vals, n, p)
    
    plt.subplot(2, 3, 5)
    bars = plt.bar(x_vals, probs, color='lightblue', alpha=0.7, label=f'Bin(n={n}, p={p})')
    
    # Destacar la barra de interés
    bars[k_destacado].set_color('red')
    bars[k_destacado].set_alpha(0.9)
    
    plt.axvline(x=k_destacado, color='red', linestyle='--', alpha=0.7, label=f'P(X={k_destacado})')
    
    plt.xlabel('Número de aciertos')
    plt.ylabel('Probabilidad')
    plt.title('Distribución Binomial - Examen')
    plt.legend()
    plt.grid(True, alpha=0.3)
    
    # Añadir texto con la probabilidad
    prob_destacada = binom.pmf(k_destacado, n, p)
    plt.text(k_destacado, prob_destacada + 0.005, f'{prob_destacada:.4f}', 
             ha='center', color='red')

def graficar_binomial_2():
    """Graficar caso 2 de distribución binomial"""
    print("\n=== GRÁFICA DISTRIBUCIÓN BINOMIAL CASO 2 ===")
    
    n = 20
    p = 0.05
    k_min = 2
    
    x_vals = np.arange(0, n+1)
    probs = binom.pmf(x_vals, n, p)
    
    plt.subplot(2, 3, 6)
    
    # Colorear barras según si X ≥ 2
    colors = ['lightgray' if x < k_min else 'orange' for x in x_vals]
    bars = plt.bar(x_vals, probs, color=colors, alpha=0.7, label=f'Bin(n={n}, p={p})')
    
    plt.axvline(x=k_min-0.5, color='red', linestyle='--', alpha=0.7, label=f'X ≥ {k_min}')
    
    plt.xlabel('Número de defectuosos')
    plt.ylabel('Probabilidad')
    plt.title('Distribución Binomial - Control Calidad')
    plt.legend()
    plt.grid(True, alpha=0.3)
    
    # Calcular y mostrar la probabilidad acumulada
    prob_acum = 1 - binom.cdf(k_min-1, n, p)
    plt.text(n/2, max(probs)/2, f'P(X ≥ {k_min}) = {prob_acum:.4f}', 
             ha='center', bbox=dict(boxstyle="round,pad=0.3", facecolor="yellow", alpha=0.7))

def calcular_todas_probabilidades_poisson():
    """Calcular todas las probabilidades Poisson para M=4"""
    print("\n=== TODAS LAS PROBABILIDADES POISSON PARA M=4 ===")
    
    M = 4
    print(f"Distribución Poisson con M = {M}")
    print("x\tP(X=x)\t\tPorcentaje")
    print("-" * 40)
    
    for x in range(0, 11):
        prob = poisson.pmf(x, M)
        print(f"{x}\t{prob:.6f}\t{prob * 100:.2f}%")
    
    # Probabilidades acumuladas
    print("\nProbabilidades acumuladas:")
    for x in range(0, 11):
        prob_acum = poisson.cdf(x, M)
        print(f"P(X ≤ {x}) = {prob_acum:.6f} = {prob_acum * 100:.2f}%")

def main():
    """Función principal"""
    print("SOLUCIÓN DEL TALLER - DISTRIBUCIONES DE PROBABILIDAD")
    print("=" * 70)
    
    # Problemas de Poisson
    prob_3 = pregunta_3_4_poisson()
    prob_5 = pregunta_5_6_poisson()
    pregunta_7_comparacion()
    
    # Problema de distribución normal
    prob_normal, z_score = problema_normal()
    
    # Problemas de distribución exponencial
    prob_exp1, lambda1 = problema_exponencial_1()
    prob_exp2, lambda2 = problema_exponencial_2()
    
    # Problemas de distribución binomial
    prob_bin1, comb1 = problema_binomial_1()
    prob_bin2, prob0, prob1 = problema_binomial_2()
    
    # Cálculos adicionales
    calcular_todas_probabilidades_poisson()
    
    print("\n" + "=" * 70)
    print("RESUMEN DE RESULTADOS:")
    print(f"Poisson P(X=3) = {prob_3:.6f} = {prob_3 * 100:.2f}%")
    print(f"Poisson P(X=5) = {prob_5:.6f} = {prob_5 * 100:.2f}%")
    print(f"Normal P(X>8) = {prob_normal:.6f} = {prob_normal * 100:.2f}%")
    print(f"Exponencial P(T<10min) = {prob_exp1:.6f} = {prob_exp1 * 100:.2f}%")
    print(f"Exponencial P(T>1500h) = {prob_exp2:.6f} = {prob_exp2 * 100:.2f}%")
    print(f"Binomial P(X=6) = {prob_bin1:.6f} = {prob_bin1 * 100:.2f}%")
    print(f"Binomial P(X≥2) = {prob_bin2:.6f} = {prob_bin2 * 100:.2f}%")
    
    # Graficar todas las distribuciones
    graficar_poisson()
    graficar_normal()
    graficar_exponencial_1()
    graficar_exponencial_2()
    graficar_binomial_1()
    graficar_binomial_2()
    
    plt.tight_layout()
    plt.show()

if __name__ == "__main__":
    main()